import express from 'express';
import { apiRouter } from '../server/api.ts';

const app = express();
app.use(express.json());

// Handle both /api prefixed and direct routes when called in Vercel Serverless
app.use('/api', apiRouter);
app.use(apiRouter);

export default app;
